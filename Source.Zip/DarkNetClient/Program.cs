﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DarkNetClient
{
    class Program
    {
        static DarkBrowser browser;
        static string[] GetArguments(string input)
        {
            List<string> toret = new List<string>();
            string temp = "";
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == ' ')
                {
                    toret.Add(temp);
                    temp = "";
                }
                else
                {
                    temp += input[i];
                }
            }
            return toret.ToArray();
        }
        static string input;
        static string[] arguments;
        static void Main(string[] args)
        {
            Console.Title = "DarkNet";
            browser = new DarkBrowser();
            Console.WriteLine("Darknet Download System, Console Display System (C) Michael Wang. 2018");
            while ((input = Console.ReadLine()) != "exit")
            {
                if (!input.EndsWith(" "))
                {
                    input += " ";
                }
                arguments = GetArguments(input);
                if (arguments[0] == "navigate")
                {
                    Console.WriteLine("Navigating to " + arguments[1]);
                    browser.Navigate(arguments[1]);
                    PrintDocument();
                }
                if(arguments[0] == "download")
                {
                    Console.WriteLine("Downloading from " + arguments[1] + ", writing to " + arguments[2]);
                    browser.Download(arguments[1], arguments[2]);
                }
                if(arguments[0] == "setsite")
                {
                    browser.site = arguments[1];
                    Console.WriteLine("Site Set");
                }
                if(arguments[0] == "restore")
                {
                    browser.site = "https://raw.githubusercontent.com/michaeljwang/Darknet/master/";
                    Console.WriteLine("Restored");
                }
            }
        }
        static void PrintDocument()
        {
            Console.Clear();
            Console.WriteLine("Darknet Download System, Console Display System (C) Michael Wang. 2018");
            Console.WriteLine("Download Information");
            Console.WriteLine("FileName: " + browser.filename+"     Site: "+browser.site);
            Console.WriteLine("---------------------------------------------------------");
            for(int i = 0; i < browser.document.Length;i++)
            {
                Console.WriteLine(browser.document[i]);
            }
        }
    }
}
