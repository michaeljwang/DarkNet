﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace DarkNetClient
{
    class DarkBrowser
    {
        public string filename = "";
        public string site;
        public string[] document;
        public DarkBrowser()
        {
            document = new string[1];
            site = "https://raw.githubusercontent.com/michaeljwang/Darknet/master/";
        }
        public void Navigate(string filename)
        {
            WebClient client = new WebClient();
            try
            {
                this.filename = filename;
                document=Parse(client.DownloadString(site+filename));
            }
            catch(Exception e)
            {
                document = new string[1];
                document[0] = e.Message;
            }
        }
        public void Download(string filename,string saveto)
        {
            WebClient client = new WebClient();
            byte[] data;
            Console.Clear();
            Console.WriteLine("Darknet Download System, Console Display (C) Michael Wang 2018");
            Console.WriteLine("Info");
            Console.WriteLine("Filename: " + filename, "   SaveTo:" + saveto);
            Console.WriteLine("Sataus");
            try
            {
                Console.WriteLine("Downloading...");
                data = client.DownloadData(site + filename);
                if (!File.Exists(saveto))
                {
                    File.Create(saveto).Close();
                }
                Console.WriteLine("Saving...");
                File.WriteAllBytes(saveto,data);
                Console.WriteLine("Done");
                Console.WriteLine("---------------------------------------------------------");
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public string[] Parse(string input)
        {
            List<string> toret = new List<string>();
            string temp = "";
            for(int i = 0; i<input.Length;i++)
            {
                if(input[i] == '|')
                {
                    toret.Add(temp);
                    temp = "";
                }
                else
                {
                    temp += input[i];
                }
            }
            return toret.ToArray();
        }
    }
}
